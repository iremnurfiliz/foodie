package com.example.foodieapp.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.foodieapp.entity.Sepettekiler
import com.example.foodieapp.repo.SepettekilerDaoRepository
import com.example.foodieapp.repo.YemeklerDaoRepository

class SepetFragmentViewModel : ViewModel() {
    val srepo = SepettekilerDaoRepository()
    var sepetListesi = MutableLiveData<List<Sepettekiler>>()

    init {
  //      sepettekileriYukle()
     //   sepetListesi = srepo.sepettekileriGetir()
    }

    fun sepettekileriYukle(){
    //    srepo.sepettekiYemekleriAl()
    }

    fun sil(yemek_id:Int){
    }

}