package com.example.foodieapp.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.navigation.Navigation
import androidx.recyclerview.widget.RecyclerView
import com.example.foodieapp.HomeFragmentDirections
import com.example.foodieapp.R
import com.example.foodieapp.SepetFragmentDirections
import com.example.foodieapp.databinding.SepetTasarimBinding
import com.example.foodieapp.entity.Sepettekiler
import com.example.foodieapp.entity.Yemekler
import com.example.foodieapp.viewmodel.DetayFragmentViewModel
import com.example.foodieapp.viewmodel.SepetFragmentViewModel
import com.google.android.material.snackbar.Snackbar
import com.squareup.picasso.Picasso

class SepetAdapter(var mContext:Context, var sepetListesi:List<Sepettekiler>)
    : RecyclerView.Adapter<SepetAdapter.SepetTasarimTutucu>() {
    inner class SepetTasarimTutucu(tasarim:SepetTasarimBinding) : RecyclerView.ViewHolder(tasarim.root) {
        var tasarim: SepetTasarimBinding
        init {
            this.tasarim = tasarim
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SepetTasarimTutucu {
        //görsel tasarımı buraya aktardık
        val layoutInflater = LayoutInflater.from(mContext)
        val tasarim:SepetTasarimBinding = DataBindingUtil.inflate(layoutInflater,R.layout.sepet_tasarim, parent,false)
        return SepetTasarimTutucu(tasarim)
    }

    override fun onBindViewHolder(holder: SepetTasarimTutucu, position: Int) {
        //döngü gibi çalışır
        val sepet = sepetListesi.get(position)
        val s = holder.tasarim

        val url = "http://kasimadalan.pe.hu/yemekler/resimler/${sepet.yemek_resim_adi}"
        Picasso.get().load(url).into(s.imageView)
        s.sepetNesnesi = sepet
        s.imageViewSil.setOnClickListener {
            Snackbar.make(it,"${sepet.yemek_adi} silinsin mi?", Snackbar.LENGTH_LONG).setAction("Evet"){
                //viewModel.sil(sepet.sepet_id)
            }.show()
        }

    }

    override fun getItemCount(): Int {
        return sepetListesi.size
    }


    /*:RecyclerView.Adapter<SepetAdapter.SepetTasarimTutucu>()
    inner class SepetTasarimTutucu (tasarim:SepetTasarimBinding) : RecyclerView.ViewHolder(tasarim.root){
        var tasarim : SepetTasarimBinding
        init {
            this.tasarim = tasarim
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SepetTasarimTutucu {
        val layoutInflater = LayoutInflater.from(mContext)
        val tasarim : SepetTasarimBinding = DataBindingUtil.inflate(layoutInflater,R.layout.sepet_tasarim, parent,false)
        return SepetTasarimTutucu(tasarim)
    }

    override fun onBindViewHolder(holder: SepetTasarimTutucu, position: Int) {
        val sepet = sepetListesi.get(position)
        val s=holder.tasarim
        val url = "http://kasimadalan.pe.hu/yemekler/resimler/${sepet.yemek_resim_adi}"
        Picasso.get().load(url).into(s.imageView)
        //s.imageView.setImageResource(
          //  mContext.resources.getIdentifier(sepet.sepet_yemek_resimAdi,"drawable",mContext.packageName))

        s.sepetNesnesi = sepet
        s.imageViewSil.setOnClickListener {
            Snackbar.make(it,"${sepet.yemek_adi} silinsin mi?", Snackbar.LENGTH_LONG).setAction("Evet"){
                //viewModel.sil(sepet.sepet_id)
            }.show()
        }
    }

    override fun getItemCount(): Int {
        return sepetListesi.size
    }*/
}