package com.example.foodieapp

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import com.example.foodieapp.R
import com.example.foodieapp.databinding.FragmentFavoritesBinding

class FavoritesFragment : Fragment() {
    private lateinit var tasarim : FragmentFavoritesBinding
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        tasarim = DataBindingUtil.inflate(inflater,R.layout.fragment_favorites, container, false)
        return tasarim.root
    }

}