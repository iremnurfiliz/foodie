package com.example.foodieapp.retrofit

class ApiUtils {

    companion object{
        val BASE_URL = "http://kasimadalan.pe.hu/"
        fun getYemeklerDaoInterface() :YemeklerDaoInterface {
            return RetrofitClient.getClient(BASE_URL).create(YemeklerDaoInterface::class.java)
        }
        fun getSepettekilerDaoInterface() : SepettekilerDaoInterface{
            return RetrofitClient.getClient(BASE_URL).create(SepettekilerDaoInterface::class.java)
        }
    }

}