package com.example.foodieapp.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.navigation.Navigation
import androidx.recyclerview.widget.RecyclerView
import com.example.foodieapp.HomeFragmentDirections
import com.example.foodieapp.R
import com.example.foodieapp.databinding.CardTasarimBinding
import com.example.foodieapp.databinding.OnerilenlerTasarimBinding
import com.example.foodieapp.entity.Yemekler
import com.example.foodieapp.viewmodel.HomeFragmentViewModel

class OnerilenlerAdapter(var mContext: Context,
                         var onerilenlerListesi:List<Yemekler>)
    : RecyclerView.Adapter<OnerilenlerAdapter.CardTasarimTutucu>()  {

    inner class CardTasarimTutucu(tasarim: OnerilenlerTasarimBinding) : RecyclerView.ViewHolder(tasarim.root) {
        var tasarim: OnerilenlerTasarimBinding

        init {
            this.tasarim = tasarim
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CardTasarimTutucu {
        val layoutInflater = LayoutInflater.from(mContext)
        val tasarim:OnerilenlerTasarimBinding = DataBindingUtil.inflate(layoutInflater, R.layout.onerilenler_tasarim, parent, false)
        return CardTasarimTutucu(tasarim)
    }

    override fun onBindViewHolder(holder: CardTasarimTutucu, position: Int) {
        val onerilen = onerilenlerListesi.get(position)
        val o = holder.tasarim

        o.imageViewOnerilenResim.setImageResource(mContext.resources.getIdentifier(onerilen.yemek_resim_adi,"drawable",mContext.packageName))
        o.textViewOnerilenYemekAd.text = onerilen.yemek_adi
    }

    override fun getItemCount(): Int {
        return onerilenlerListesi.size
    }
}