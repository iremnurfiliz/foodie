package com.example.foodieapp.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.example.foodieapp.R
import com.example.foodieapp.databinding.KampanyalarTasarimBinding
import com.example.foodieapp.entity.Yemekler

class KampanyalarAdapter(var mContext: Context,
                         var kampanyalarListesi:List<Yemekler>) : RecyclerView.Adapter<KampanyalarAdapter.CardTasarimTutucu>() {
    inner class CardTasarimTutucu(tasarim: KampanyalarTasarimBinding) : RecyclerView.ViewHolder(tasarim.root) {
        var tasarim: KampanyalarTasarimBinding

        init {
            this.tasarim = tasarim
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CardTasarimTutucu {
        val layoutInflater = LayoutInflater.from(mContext)
        val tasarim:KampanyalarTasarimBinding = DataBindingUtil.inflate(layoutInflater, R.layout.kampanyalar_tasarim, parent, false)
        return CardTasarimTutucu(tasarim)
    }

    override fun onBindViewHolder(holder: CardTasarimTutucu, position: Int) {
        val kampanya = kampanyalarListesi.get(position)
        val k = holder.tasarim

        k.imageViewKampanya.setImageResource(mContext.resources.getIdentifier(kampanya.yemek_resim_adi,"drawable",mContext.packageName))

    }

    override fun getItemCount(): Int {
        return kampanyalarListesi.size
    }
}