package com.example.foodieapp

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.viewModels
import androidx.navigation.Navigation
import androidx.navigation.fragment.navArgs
import com.example.foodieapp.databinding.FragmentDetayBinding
import com.example.foodieapp.databinding.FragmentSepetBinding
import com.example.foodieapp.entity.Sepettekiler
import com.example.foodieapp.entity.Yemekler
import com.example.foodieapp.viewmodel.DetayFragmentViewModel
import com.google.android.material.snackbar.Snackbar
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.fragment_detay.*

class DetayFragment : Fragment() {
    private lateinit var tasarim : FragmentDetayBinding
    private lateinit var viewModel : DetayFragmentViewModel
    companion object {
        var yemekAdi: String ="boş"
        var yemekFiyat: Int =  0
        var yemekResim: String = "boş"
        var yemekAdet: Int = 0
        var sepetAdet: Int = 0
        var sepetKullanici : String = "boş"
    }
    var sayi = 0

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        tasarim = DataBindingUtil.inflate(inflater,R.layout.fragment_detay, container, false)
        val bundle:DetayFragmentArgs by navArgs()
        val gelenYemek = bundle.yemek



        val url = "http://kasimadalan.pe.hu/yemekler/resimler/${gelenYemek.yemek_resim_adi}"
        Picasso.get().load(url).into(tasarim.imageViewResim)
        tasarim.detayFragment = this
        tasarim.textViewAdet = "0"
        tasarim.detayFragmentToolbarBaslik = gelenYemek.yemek_adi
        tasarim.detayNesnesi = gelenYemek

        tasarim.buttonSepeteEkle.setOnClickListener {

            if (sayi>0) {

                val yemek_adet = tasarim.textViewAdetSayisi.text.toString()
                sepeteEkleButonu(yemek_adet.toInt())
                tasarim.detayNesnesi = gelenYemek

                Snackbar.make(it, "$yemek_adet adet sepete eklendi", Snackbar.LENGTH_SHORT).show()

            }
            else Snackbar.make(it,"Lütfen adet bilgisi giriniz", Snackbar.LENGTH_SHORT).show()
        }

       /* tasarim.buttonSepeteEkle.setOnClickListener {
            val yemek_adet = tasarim.textViewAdetSayisi.text.toString()
            if (sayi>0) {
                //Navigation.findNavController(it).navigate(R.id.sepetGecis)
                Snackbar.make(it, "$yemek_adet adet sepete eklendi", Snackbar.LENGTH_SHORT).show()
                tasarim.imageViewResim.setImageResource(resources
                    .getIdentifier(gelenYemek.yemek_resim_adi,"drawable",requireContext().packageName))

                tasarim.textViewYemekAdi.text = gelenYemek.yemek_adi
                tasarim.textViewYemekFiyati.text = gelenYemek.yemek_fiyat.toString()
                tasarim.textViewAdetSayisi.text = gelenYemek.yemek_adi

                yemekAdi = gelenYemek.yemek_adi
                yemekFiyat = gelenYemek.yemek_fiyat*sayi
                yemekResim = gelenYemek.yemek_resim_adi
                yemekAdet = sayi
                sepetAdet = sayi
            }
            else Snackbar.make(it,"Lütfen adet bilgisi giriniz", Snackbar.LENGTH_SHORT).show()
        }*/
        return tasarim.root
    }

    fun sepeteEkleButonu(adetSayisi:Int){
        Log.e("Sepet eklendi", "$adetSayisi")

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val tempViewModel:DetayFragmentViewModel by viewModels()
        viewModel = tempViewModel
    }

    fun sayiArtir(){
        sayi++
        tasarim.textViewAdetSayisi.text=sayi.toString()

    }
    fun  sayiAzalt(){
        if (sayi<=0) sayi = 0
        else sayi--
        tasarim.textViewAdetSayisi.text = sayi.toString()
    }

   /* fun sepeteEkleButonu(v:View){
        val yemek_adet = tasarim.textViewAdetSayisi.text.toString()
        if (sayi>0) {
            //Navigation.findNavController(v).navigate(R.id.sepetGecis)
            val bundle:DetayFragmentArgs by navArgs()
            val gelenYemek = bundle.yemek
            Snackbar.make(v, "$yemek_adet adet sepete eklendi", Snackbar.LENGTH_SHORT).show()
            tasarim.imageViewResim.setImageResource(resources
                .getIdentifier(gelenYemek.yemek_resim_adi,"drawable",requireContext().packageName))
            tasarim.textViewYemekAdi.text = gelenYemek.yemek_adi
            tasarim.textViewYemekFiyati.text = gelenYemek.yemek_fiyat.toString()

            yemekAdi = gelenYemek.yemek_adi
            yemekFiyat = gelenYemek.yemek_fiyat*sayi
            yemekResim = gelenYemek.yemek_resim_adi
            yemekAdet = sayi
            sepetAdet = sayi
            /*DetayFragment.yemekAdi = gelenYemek.yemek_adi
            DetayFragment.yemekFiyat = gelenYemek.yemek_fiyat
            DetayFragment.yemekResim = gelenYemek.yemek_resim_adi
            DetayFragment.yemekAdet = sayi*/
        }
        else Snackbar.make(v,"Lütfen adet bilgisi giriniz", Snackbar.LENGTH_SHORT).show()

    }*/

    fun resimGoster(){
        val url = "http://kasimadalan.pe.hu/yemekler/resimler/"
        Picasso.get().load(url).into(tasarim.imageViewResim)
    }


}