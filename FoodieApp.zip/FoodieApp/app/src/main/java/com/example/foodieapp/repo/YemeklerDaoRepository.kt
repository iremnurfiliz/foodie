package com.example.foodieapp.repo

import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.example.foodieapp.entity.*
import com.example.foodieapp.retrofit.ApiUtils
import com.example.foodieapp.retrofit.RetrofitClient
import com.example.foodieapp.retrofit.SepettekilerDaoInterface
import com.example.foodieapp.retrofit.YemeklerDaoInterface
import com.squareup.picasso.Picasso
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class YemeklerDaoRepository {

    var yemekListesi : MutableLiveData<List<Yemekler>>
    var ydao : YemeklerDaoInterface

    init {
        ydao = ApiUtils.getYemeklerDaoInterface()
        yemekListesi = MutableLiveData()
    }

    fun sepeteEkle(yemek_adi:String,yemek_resim_adi:String,yemek_fiyat:Int,yemek_siparis_adet:Int){
        ydao.sepeteYemekEkle(yemek_adi, yemek_resim_adi, yemek_fiyat, yemek_siparis_adet, kullanici_adi = "irem")
            .enqueue(object : Callback<CRUDCevap>{
                override fun onResponse(call: Call<CRUDCevap>, response: Response<CRUDCevap>) {
                    val success = response.body().success
                    val message = response.body().message
                    Log.e("Yemek Kayıt","$success - $message")
                }
                override fun onFailure(call: Call<CRUDCevap>?, t: Throwable?) {}
            })
    }

    fun yemekAra(aramaKelimesi:String){
        Log.e("Yemek Ara","${aramaKelimesi}")
    }

    fun yemekleriGetir() : MutableLiveData<List<Yemekler>>{
        return  yemekListesi
    }

    fun tumYemekleriAl(){
        ydao.tumYemekleriGetir().enqueue(object : Callback<YemeklerCevap>{
            override fun onResponse(call: Call<YemeklerCevap>, response: Response<YemeklerCevap>) {
                val liste = response.body().yemekler
                yemekListesi.value = liste
            }
            override fun onFailure(call: Call<YemeklerCevap>?, t: Throwable?) {}
        })
    }

}