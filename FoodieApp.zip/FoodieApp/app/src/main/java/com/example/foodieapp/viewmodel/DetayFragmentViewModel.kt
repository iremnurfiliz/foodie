package com.example.foodieapp.viewmodel

import androidx.lifecycle.ViewModel
import com.example.foodieapp.repo.YemeklerDaoRepository

class DetayFragmentViewModel : ViewModel() {
    val yrepo = YemeklerDaoRepository()

    fun ekleSepet(yemek_adi:String,yemek_resim_adi:String,yemek_fiyat:Int,yemek_siparis_adet:Int){
        yrepo.sepeteEkle(yemek_adi,yemek_resim_adi,yemek_fiyat,yemek_siparis_adet)
    }

}