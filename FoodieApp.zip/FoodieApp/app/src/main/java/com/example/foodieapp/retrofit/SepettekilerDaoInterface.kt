package com.example.foodieapp.retrofit

import com.example.foodieapp.entity.CRUDCevap
import com.example.foodieapp.entity.SepettekilerCevap
import retrofit2.Call
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET
import retrofit2.http.POST

interface SepettekilerDaoInterface {


    @GET("yemekler/sepettekiYemekleriGetir.php")
    fun sepettekiYemekleriGetir() : Call<SepettekilerCevap>

    @POST("yemekler/sepettenYemekSil.php")
    @FormUrlEncoded
    fun sepettekiYemekleriSil() : Call<CRUDCevap>

}