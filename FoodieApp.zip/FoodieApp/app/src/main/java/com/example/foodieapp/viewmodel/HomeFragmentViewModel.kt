package com.example.foodieapp.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.foodieapp.entity.Yemekler
import com.example.foodieapp.repo.YemeklerDaoRepository

class HomeFragmentViewModel : ViewModel() {
    val yrepo = YemeklerDaoRepository()
    var yemekListesi = MutableLiveData<List<Yemekler>>()

    init {
        yemekleriYukle()
        yemekListesi = yrepo.yemekleriGetir()
    }

    fun yemekleriYukle(){
        yrepo.tumYemekleriAl()
    }

    fun ara(aramaKelimesi:String){
        yrepo.yemekAra(aramaKelimesi)
    }

}