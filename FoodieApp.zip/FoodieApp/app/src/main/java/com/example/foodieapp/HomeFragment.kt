package com.example.foodieapp

import android.os.Bundle
import android.util.Log
import android.view.*
import androidx.fragment.app.Fragment
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.viewModels
import androidx.navigation.ui.NavigationUI
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.example.foodieapp.adapter.KampanyalarAdapter
import com.example.foodieapp.adapter.OnerilenlerAdapter
import com.example.foodieapp.adapter.YemeklerAdapter
import com.example.foodieapp.databinding.FragmentHomeBinding
import com.example.foodieapp.entity.Yemekler
import com.example.foodieapp.viewmodel.HomeFragmentViewModel
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.card_tasarim.view.*

class HomeFragment : Fragment(), SearchView.OnQueryTextListener {
    private lateinit var tasarim : FragmentHomeBinding
    private lateinit var viewModel : HomeFragmentViewModel
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        tasarim = DataBindingUtil.inflate(inflater, R.layout.fragment_home, container, false)

        tasarim.rvSonSiparis.layoutManager = StaggeredGridLayoutManager(1,StaggeredGridLayoutManager.HORIZONTAL)
        val onerilenlerListesi = ArrayList<Yemekler>()
        val o1 = Yemekler(1,"Baklava","baklava",20)
        val o2 = Yemekler(2,"Bowl","bowl",20)
        val o3 = Yemekler(3,"Tavuk But","but",20)
        val o4 = Yemekler(4,"Çökertme Kebabı","cokertme",20)
        val o5 = Yemekler(5,"Hamburger","hamburger",20)
        val o6 = Yemekler(6,"Kebap","kebap",20)
        val o7 = Yemekler(7,"Makarna","kebap",20)
        val o8 = Yemekler(8,"Pide","pide",20)
        val o9 = Yemekler(9,"Pizza","pizza",20)
        val o10 = Yemekler(10,"Salata","salata",20)
        val o11 = Yemekler(11,"Sandwich","sandwich",20)
        val o12 = Yemekler(12,"Somon","somon",20)
        val o13 = Yemekler(13,"Sushi","sushi",20)
        val o14 = Yemekler(14,"Tiramisu","tiramisu",20)
        onerilenlerListesi.add(o1)
        onerilenlerListesi.add(o2)
        onerilenlerListesi.add(o3)
        onerilenlerListesi.add(o4)
        onerilenlerListesi.add(o5)
        onerilenlerListesi.add(o6)
        onerilenlerListesi.add(o7)
        onerilenlerListesi.add(o8)
        onerilenlerListesi.add(o9)
        onerilenlerListesi.add(o10)
        onerilenlerListesi.add(o11)
        onerilenlerListesi.add(o12)
        onerilenlerListesi.add(o13)
        onerilenlerListesi.add(o14)
        val adapter = OnerilenlerAdapter(requireContext(),onerilenlerListesi)
        tasarim.rvSonSiparis.adapter = adapter


        tasarim.rvKampanyalar.layoutManager = StaggeredGridLayoutManager(1,StaggeredGridLayoutManager.HORIZONTAL)
        val kampanyalarListesi = ArrayList<Yemekler>()
        val k1 = Yemekler(1,"Kampanya1","kampanya1",0)
        val k2 = Yemekler(2,"Kampanya2","kampanya2",0)
        val k3 = Yemekler(3,"Kampanya3","kampanya3",0)
        val k4 = Yemekler(4,"Kampanya4","kampanya4",0)
        kampanyalarListesi.add(k1)
        kampanyalarListesi.add(k2)
        kampanyalarListesi.add(k3)
        kampanyalarListesi.add(k4)
        val adapter2 = KampanyalarAdapter(requireContext(),kampanyalarListesi)
        tasarim.rvKampanyalar.adapter = adapter2

        tasarim.foodieBaslik = "Foodie"
        tasarim.onerilenlerYazisi = "Kampanyalar"
        tasarim.kategorilerYazisi = "Yemekler"
        tasarim.sonSiparisOneriYazisi = "Son Siparişlerinize Özel Olarak..."

        (activity as AppCompatActivity).setSupportActionBar(tasarim.toolbarAnasayfa)

        viewModel.yemekListesi.observe(viewLifecycleOwner){
            val adapter = YemeklerAdapter(requireContext(),it,viewModel)
            tasarim.yemeklerAdapter = adapter
        }

        return tasarim.root
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
        val tempViewModel : HomeFragmentViewModel by viewModels()
        viewModel = tempViewModel
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.toolbar_menu,menu)

        //Aramayı sağlayan kod
        val item = menu.findItem(R.id.action_ara)
        val searchView = item.actionView as SearchView
        searchView.setOnQueryTextListener(this)

        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onQueryTextSubmit(query: String): Boolean {
        viewModel.ara(query)
        return true
    }

    override fun onQueryTextChange(newText: String): Boolean {
        viewModel.ara(newText)
        return true
    }

}