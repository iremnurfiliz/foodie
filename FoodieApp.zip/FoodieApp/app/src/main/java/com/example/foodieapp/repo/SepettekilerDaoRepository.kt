package com.example.foodieapp.repo

import androidx.lifecycle.MutableLiveData
import com.example.foodieapp.entity.Sepettekiler
import com.example.foodieapp.entity.SepettekilerCevap
import com.example.foodieapp.entity.YemeklerCevap
import com.example.foodieapp.retrofit.ApiUtils
import com.example.foodieapp.retrofit.SepettekilerDaoInterface
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SepettekilerDaoRepository {

    var sepettekilerListesi : MutableLiveData<List<Sepettekiler>>
    var sdao : SepettekilerDaoInterface

    init {
        sdao = ApiUtils.getSepettekilerDaoInterface()
        sepettekilerListesi = MutableLiveData()
    }

    fun sepettekileriGetir() : MutableLiveData<List<Sepettekiler>>{
        return sepettekilerListesi
    }

    fun sepettekiYemekleriAl(){
        sdao.sepettekiYemekleriGetir().enqueue(object: Callback<SepettekilerCevap>{
            override fun onResponse(call: Call<SepettekilerCevap>, response: Response<SepettekilerCevap>) {
                val liste = response.body().sepet_yemekler
                sepettekilerListesi.value = liste
            }
            override fun onFailure(call: Call<SepettekilerCevap>?, t: Throwable?) {}
        })
    }
}