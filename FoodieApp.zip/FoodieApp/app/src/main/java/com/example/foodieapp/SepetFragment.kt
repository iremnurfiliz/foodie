package com.example.foodieapp

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.viewModels
import androidx.navigation.NavArgs
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.example.foodieapp.R
import com.example.foodieapp.adapter.SepetAdapter
import com.example.foodieapp.adapter.YemeklerAdapter
import com.example.foodieapp.databinding.FragmentAccountBinding
import com.example.foodieapp.databinding.FragmentSepetBinding
import com.example.foodieapp.entity.Sepettekiler
import com.example.foodieapp.viewmodel.HomeFragmentViewModel
import com.example.foodieapp.viewmodel.SepetFragmentViewModel
import kotlinx.android.synthetic.main.sepet_tasarim.view.*

class SepetFragment : Fragment() {
    private lateinit var tasarim : FragmentSepetBinding
    private lateinit var viewModel : SepetFragmentViewModel


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        tasarim = DataBindingUtil.inflate(inflater,R.layout.fragment_sepet, container, false)


        tasarim.rvSepet.layoutManager = LinearLayoutManager(requireContext())

        viewModel.sepetListesi.observe(viewLifecycleOwner){
            val adapter = SepetAdapter(requireContext(),it)
            tasarim.sepetAdapter = adapter
        }
        return tasarim.root
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val tempViewModel : SepetFragmentViewModel by viewModels()
        viewModel = tempViewModel
    }

}